## Assignment 2

Has multiple external libraries. Please install before running.

```
python3 main.py
```

### Output 1

![Output 1](./out1.png) 

### Output 2

![Output 2](./out2.png) 