# Assignent 1

`python3 main.py`

*Use Ctrl+W to close any graphs*

## Q1
All 3 of graham scan, divide and conquer and a simple bruteforce tecnique are in the code. To plot the graphs (for graham and brute force uncomment code). For brute force, add (plot=True) when calling method

In the time/input vs output graphs, the points tend to overlap due to almost same size of output.

Input is generated randomly.

## Q2
Q2 is pretty straight forward. Cutoff of color intensity can be set in the code. Boundry changes based on that.

## Q3
Also straightforward. Points hardcoded in. Input described in document. 
